/*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.apache.tomcat.jni;

/* Import needed classes */
import java.nio.ByteBuffer;

/** Socket
 *
 * @author Mladen Turk
 *
 * @deprecated  The scope of the APR/Native Library will be reduced in Tomcat
 *              10.1.x / Tomcat Native 2.x onwards to only include those
 *              components required to provide OpenSSL integration with the NIO
 *              and NIO2 connectors.
 */
@Deprecated
public class Socket {

    /* Standard socket defines */
    public static final int SOCK_STREAM = 0;
    public static final int SOCK_DGRAM  = 1;
    /*
     * apr_sockopt Socket option definitions
     */
    public static final int APR_SO_LINGER       = 1;    /** Linger */
    public static final int APR_SO_KEEPALIVE    = 2;    /** Keepalive */
    public static final int APR_SO_DEBUG        = 4;    /** Debug */
    public static final int APR_SO_NONBLOCK     = 8;    /** Non-blocking IO */
    public static final int APR_SO_REUSEADDR    = 16;   /** Reuse addresses */
    public static final int APR_SO_SNDBUF       = 64;   /** Send buffer */
    public static final int APR_SO_RCVBUF       = 128;  /** Receive buffer */
    public static final int APR_SO_DISCONNECTED = 256;  /** Disconnected */
    /** For SCTP sockets, this is mapped to STCP_NODELAY internally. */
    public static final int APR_TCP_NODELAY     = 512;
    public static final int APR_TCP_NOPUSH      = 1024; /** No push */
    /** This flag is ONLY set internally when we set APR_TCP_NOPUSH with
     * APR_TCP_NODELAY set to tell us that APR_TCP_NODELAY should be turned on
     * again when NOPUSH is turned off
     */
    public static final int APR_RESET_NODELAY   = 2048;
    /** Set on non-blocking sockets (timeout != 0) on which the
     * previous read() did not fill a buffer completely.  the next
     * apr_socket_recv()  will first call select()/poll() rather than
     * going straight into read().  (Can also be set by an application to
     * force a select()/poll() call before the next read, in cases where
     * the app expects that an immediate read would fail.)
     */
    public static final int APR_INCOMPLETE_READ = 4096;
    /** like APR_INCOMPLETE_READ, but for write
     */
    public static final int APR_INCOMPLETE_WRITE = 8192;
    /** Don't accept IPv4 connections on an IPv6 listening socket.
     */
    public static final int APR_IPV6_V6ONLY      = 16384;
    /** Delay accepting of new connections until data is available.
     */
    public static final int APR_TCP_DEFER_ACCEPT = 32768;

    /** Define what type of socket shutdown should occur.
     * apr_shutdown_how_e enum
     */
    public static final int APR_SHUTDOWN_READ      = 0; /** no longer allow read request */
    public static final int APR_SHUTDOWN_WRITE     = 1; /** no longer allow write requests */
    public static final int APR_SHUTDOWN_READWRITE = 2; /** no longer allow read or write requests */

    public static final int APR_IPV4_ADDR_OK = 0x01;
    public static final int APR_IPV6_ADDR_OK = 0x02;

    public static final int APR_UNSPEC = 0;
    public static final int APR_INET   = 1;
    public static final int APR_INET6  = 2;
    public static final int APR_UNIX   = 3;

    public static final int APR_PROTO_TCP  =   6; /** TCP  */
    public static final int APR_PROTO_UDP  =  17; /** UDP  */
    public static final int APR_PROTO_SCTP = 132; /** SCTP */

    /**
     * Enum to tell us if we're interested in remote or local socket
     * apr_interface_e
     */
    public static final int APR_LOCAL  = 0;
    public static final int APR_REMOTE = 1;

    /* Socket.get types */
    public static final int SOCKET_GET_POOL = 0;
    public static final int SOCKET_GET_IMPL = 1;
    public static final int SOCKET_GET_APRS = 2;
    public static final int SOCKET_GET_TYPE = 3;

    /**
     * Create a socket.
     * @param family The address family of the socket (e.g., APR_INET).
     * @param type The type of the socket (e.g., SOCK_STREAM).
     * @param protocol The protocol of the socket (e.g., APR_PROTO_TCP).
     * @param cont The parent pool to use
     * @return The new socket that has been set up.
     * @throws Exception Error creating socket
     */
    public static native long create(int family, int type,
                                     int protocol, long cont)
        throws Exception;


    /**
     * Shutdown either reading, writing, or both sides of a socket.
     * <br>
     * This does not actually close the socket descriptor, it just
     *      controls which calls are still valid on the socket.
     * @param thesocket The socket to close
     * @param how How to shutdown the socket.  One of:
     * <PRE>
     * APR_SHUTDOWN_READ         no longer allow read requests
     * APR_SHUTDOWN_WRITE        no longer allow write requests
     * APR_SHUTDOWN_READWRITE    no longer allow read or write requests
     * </PRE>
     * @return the operation status
     */
    public static native int shutdown(long thesocket, int how);

    /**
     * Close a socket.
     * @param thesocket The socket to close
     * @return the operation status
     */
    public static native int close(long thesocket);

    /**
     * Destroy a pool associated with socket
     * @param thesocket The destroy
     */
    public static native void destroy(long thesocket);

    /**
     * Bind the socket to its associated port
     * @param sock The socket to bind
     * @param sa The socket address to bind to
     * This may be where we will find out if there is any other process
     *      using the selected port.
     * @return the operation status
     */
    public static native int bind(long sock, long sa);

    /**
     * Listen to a bound socket for connections.
     * @param sock The socket to listen on
     * @param backlog The number of outstanding connections allowed in the sockets
     *                listen queue.  If this value is less than zero, the listen
     *                queue size is set to zero.
     * @return the operation status
     */
    public static native int listen(long sock, int backlog);

    /**
     * Accept a new connection request
     * @param sock The socket we are listening on.
     * @param pool The pool for the new socket.
     * @return  A copy of the socket that is connected to the socket that
     *          made the connection request.  This is the socket which should
     *          be used for all future communication.
     * @throws Exception Socket accept error
     */
    public static native long acceptx(long sock, long pool)
        throws Exception;

    /**
     * Accept a new connection request
     * @param sock The socket we are listening on.
     * @return  A copy of the socket that is connected to the socket that
     *          made the connection request.  This is the socket which should
     *          be used for all future communication.
     * @throws Exception Socket accept error
     */
    public static native long accept(long sock)
        throws Exception;

    /**
     * Set an OS level accept filter.
     * @param sock The socket to put the accept filter on.
     * @param name The accept filter
     * @param args Any extra args to the accept filter.  Passing NULL here removes
     *             the accept filter.
     * @return the operation status
     */
    public static native int acceptfilter(long sock, String name, String args);

    /**
     * Query the specified socket if at the OOB/Urgent data mark
     * @param sock The socket to query
     * @return <code>true</code> if socket is at the OOB/urgent mark,
     *         otherwise <code>false</code>.
     */
    public static native boolean atmark(long sock);

    /**
     * Issue a connection request to a socket either on the same machine
     * or a different one.
     * @param sock The socket we wish to use for our side of the connection
     * @param sa The address of the machine we wish to connect to.
     * @return the operation status
     */
    public static native int connect(long sock, long sa);

    /**
     * Send data over a network.
     * <PRE>
     * This functions acts like a blocking write by default.  To change
     * this behavior, use apr_socket_timeout_set() or the APR_SO_NONBLOCK
     * socket option.
     *
     * It is possible for both bytes to be sent and an APR errAPR errAPt to 62umenn Tomcat
 *  [*
  to the0 socket wetto apr_stat
    eOCK
     * socket option.
     Pt toocket option.
     *
     * It    throwwwwt oprAPR erwetto ap    .
 a�    . use'r      cke�  * @param sourgent mark,
     *         otherwise <code>false</c diff,
     * ur side of the connectio0 . use'r      cke�  * @param sourg_9�u�6iu�aeither onp/�he operation star(er�m sock� *         otherwise <code>fa�k� *  c;H(insock, String namnumberY�blite <code> connecrk, int acde of the connectio0 . use'r      cke�  * @param s�;ing connections allowed in the sockets
     *                listen queue.  If OB/Urint li*       ou un *  li*       ou _STAal in+hon was incompl�     Used
s cWIT@param sour�AaraITE nal booi  A coh�It is pongDON	ompl
    public static�s acts lnlblic stic native voill find ectio0 . use'r      cke�  * @ill find connecrk,tpackage org.a-ock�option.
   et bynnecrmmmmmmmmmmlter.  PassEpassEpassEpa�     Used
s cWmlter2a connecCRR_EM�   *ecrmmv     9_ed ym soows Except�kage orgotive voill find ecti(39�lincompl�    mpl�    mplIt is mmlter.  Pannecrk,tpacorgotiv GWlic sve vncompSI�0);
    p�ff,
    Srmmmmmmmmmmler al6tm sock� *         otherwise <code> but
r      cke�  * @ill find co  made  sourgenN=mmmmmsl of the socket (e.g., APR"of the descriptor array must be two times the size of pollset.
     *  CRR_EM�   *ecrmm filter.  Passing NULL here removes
     *             t�Ri.  ouFLL herTUSocket (e.g.,

    public static finaand
        }aeE** Don't accept IPv4 connectiS1750 0000000   */_;

    /**:d)�ic sMe.
  �tt be   /*bSmark,
     *         otherwiDWRITE = atictvecified socket if at the OOd)��s isIra�e liste0%Iept(lon�  = (ra�e liste0%Iept(lon�  = (ra�e liste0%Iept(lon�  = (ra^oeliste0%Iept(lon�  = (ra�e liste0%Iepp+Q(t--ion 2Y/
    public int geS`
    -ion 2Y/
   �t(lon�  = (ra�e liste0%Iept(lon�  = (ra^oeliste0lon�  = et.
   "n 2s�fuie liste0te're  /*bSmarU.
     *       2s, int flags, long ttl)
   J   �fuie lise pollc int geS`
    -ion 2Y/
   �t(loy ma�nt geS`
    -ion 2Y/
     
   l�/*bSmaon 2Y/:d)�ic sMe.
  �tt be   /*bSmatati*bSF       = 64;   /** Send (ocket (e.g.S     = (APR_OS_START_STATUS + 19);
    public static final int APR_FILEBASED     = (APR_OS_START_STATUS + 20);
    public static final int APR_KEYBASED      = (APR_OS_START_STATUS + 21);
    public static final int APR_EINIT         = (APR_OS_START_STATUS +�pe this f�iiead would fail.)
     */
    c static final boolean Aas us   ARRU                would fail.)
     */
    c static final boolean Aas us   ARRU                would fail.)
     */
    c static final boolean Aas us   ARRU                would fail.)
     */
    c static final boolean Aas us   ARRU                would fail.)
     */
   Epet to put the accept filtezve!cat/jnUL             to_~t.jnfion 2Y/a               aticrt to put
   Ex�?�/efail.)
     */
   fincke�  *ithof signaled descriptors (�t APR_nal int APR_�q�+��C{ke socke)
     */
   fincke�  *ithof sitictvecified socket if at the OOd)��s is   ��C{C{ke tictvOd)��s ist tictvOd)n_a�nt geS`
       NODELAY shouln 1;
    public static final int SOiq�+�thof sitictvecified socket if aonnectiS1750 0000000   */_;

_EABOVtocket if aUT(int s)  aonnectiS1  *ified sSNB/UriUR@para# ARRU                would fail.)
�s inSNB/UriUR@para# ARRU            Hatic final boolean Aas us   ARRU    ochram pollsmv     9_ed ym ati1,    = (APR_OS_START_STATUS + 7);
    public static final int APR_INCOMPLETu;
    public statictiS1p0000000   */_;

_EABOVtocket if aUT(int s)  aonnec}cSa{2Pv     9_ed ym soows Except�kage orgSTARe3

   *ithoDkage the Liege tnaltic fBOVtR�t APR_UNSPEC = 0;
   *"ksot  would fail.)
     */
    c s�" at the �tR�t APR_UNSPEC = 0;
   *"ksot  would fail.)
     */
    c s�" at the �tR�t   eOCK
     * socket option.
   ksot  woe�p            ional flagsNB/UriUR@para# ARRU     �d�r�6r   ARRU                     option.
   ksot  woe�p      '.lS Ex�?�/efail.)
     */
   fincke�  *ithof signaled descriptors (�t AP4Su9bool th�ol (*/efEC =t2}LI regaru2t    public 2eue.  If OB/Uri     */
  �-          ional flagsNB/UriUR@para# ARRU     �   ��s iiii s)  aonnec}cSa{2Pv     9_Timeout in mi�Lual booi  A coh�It is pongDON	oman3=s� booil booi  A coh�It is pongDON	oman3�t   eOCK
   2}LIVbos(                    /*
 *  Licensed to tt in e',

    public sth�It on.
   ksot  woe�p      'I)therw�_POLL�/ot s) ksot  woe�p   ike`e�_POLL�/ot s) ksot  woe�p   Bke`e�_POLL�para ksot  woe�p   ike`e�_POLL�/ot LL�paC = 0;po boo sMe.
  �tt be   /*b0000000 ��/ta    'I)therw�_POLL�/ot s) ksot  woe�p   ike`e�_POLL�/ot i s)  aonnec}cSa{2Pv     9_Timeo i s)  aonnR {%sl of  mpl�    mplIt is mmlter.  Pannecrk,s�e`e�_POl.)
         'I)therw�_Pd eOCKstatic fin   *"ksuld oundatioerw�_Pd eOnh�It is p = 0x001"Sksot  woe�p   ike`e�_POLL�/ot i s)  in   *"ksuld oundatioerw�_Pttwoulo\_nf�e s)  in   *"ksuld oundeither�{oon.
   ksot  woeItratatic final woe�p      'U                     option.
  G��tnaltulonger j  tany other pro� uMI            _POLL�/_ENOTIMPL(int s)   { return is(s, 73); }
    public static final boolean APR_STE          efs�P_�t has  -ion 2Y/
 iopet to�p  socketn    o�p  socketnDnf�e s)  in   � APR_Ssot  woeItratatic final woe�p     N�(wa#  10.1.xB�crmm l woe�p      'U                  ot  woeCurn ThsIR_Ssot  wove!cat/jnUL        �1tlb_STE �STATUwi�eAnnDDs    F) under one o-t fltEABOVtocket if aU�U:�eAias  -ion 2Y/
     */ F) under one o-t fltEABOVtocket if aU�U:�eAias  -ion 2Y/    veci            would fail.)
     */
    c static final boolean Agaru2t   R@pa PassEpassEpassEpa�    t APt])v     publi#r @deprec*"ksul_)v  /efail.)
    Idail.piS1750 0000000   */_;

_EABOb APt])* @param tk1750 nal bo7�/_ENOTIMPL more
 L            l bod nal bo7�/_ENOTIMPL more
 L            l �.a-ock�o�ABOb APtassEptlb_Sblic static final int APR_POLL_SOCKE;b_Sblic static final int APR_POLL_ be two times the size of poll
)v  /efail.uests */
    puep�/e o�D'ive 2.x onwards s) ksot  m�e
   2}LIVbosb_Sb  * Return a human readabe
   2}LIVbosb_Sb  * Return a human r/    veci            would fa|k1750 nal bo7�/_ENEp  public static native int=d�MPL more
 L            l �.a-ock�o�ABOb ck�o�ABOb ck�o�ABOb ck�o�ABOb ce<�Dint APR_POLL_SOCKE;b_Sblic st3 */
    public statieEthe connection request.  T�Vation status
  Ewna_� lb_STE �STATUwi�eAnnDDs    F)e�pu|k1750 nal btion            pU      sdd a sockemore
 L            l bod nalxGUpe this f�ii; }
    public static c final i'
     */
    c staticb    TimenDDs ockeP4Suaais(s,pU      sdd a sockemo}er one o-t fltEABOVtockeEEalxGUpe this f�ii; }OBckeP4}er one o-t LxGUpe this ftE4  'U     lic stata�e this f�ii; }OBckeP4}er one o-t Lxcomp   F)e�pu|k1750 nal btion    ublic stay4}er one o-t�al boolean APR_STATUS_IS_EBADIP(int s)     { return is(s, 16); }
    public static final boolean APR_STATUS_IS_EBADMASK(int s)   { return is(s, 17); }
    /* empty slot: +18 */
    public static final boolean APR_STATUS_IS_EDSOPEN(int s)    { return is(s, 19  ooP(int s_STATUS_IS_EBADIP(int s)     { return is(s, 16); }
    public static final boolean APR_STATUS_IS_EBADMASK(in5int s): +1z { s whW P(int s_u4tap�v   {�_�Y1z { s whW P(int s_u4tap�v   {�_�Y1z { sdesc�  {�_�Y1z { s whW P(int s_  {�_�Y1z {ge tnatOboolean Iosb_S {�_�ns.
     * @param sock The ̜final int SOCK_nt APR_P��� */nP4tap�{ return is(s, 25); }
    public staticlong i�l int SOCK_nt APR_P��� */nP4tap�{ return is(s, 25); }
    public staticlong i�l nUL    A returneturn is(eturneturn is(eturror
     */
    public static native lE/* Import needed classor
Nt *"ksot  would fer�llic s"ksot 25);t     n is(eturror
    pu);t     n ait     n ait     n ait     n ait   would fer�llic s"ksot 25);t     n is(eturaturn �/Cr{�_��,��N_�t oe	ompl
ect�Zm fihuman  * �urn a�V�Zm fihuman n �/Cr{�_� mD�{�twortk�o�ABOb APtassEptlb_Sblic static final int APR_POLL_SOCKE;b_Sblic static final int APR_POLL_ be two times the size of poll
)v  /efail.uests */
    puep�/e o�D'ive 2.x onwards s) ksot  m�e
   2}LIVbosb_Sb  * Return a human readabe
   2}LIVbosb_Sb  * Return     nr�O� woulPOLL_SOCKE;b_Sbe=fnal int b  * is(s, { returnLoeliste0lont fi�V�Zm fULoelist�  sdd a soc�� C�v =therw�_*
 *fi�
  Gs tN  aonnRASK(inp   Bke`e�_Pac nativZ<is(eturneturn is(eturror
     */
    pfcopy of the socketfa b  uL=
tse apr_socket_
Rfi�V�Zm,C#,lonpAPR_K��A sdd a soc�Es 2.x onwards s) ksot  m�e
   2}LIVbosb_Sb  * Return a human reV)ge4s s) k�Ar��V�Zm,C#,lonpAPR_K��A sdd a so 2}LIVbol lonetfa bfS%STATUS*  Senmors puep�st APR_P��� */nP4tap�{ return is(s, 25); R_K��t APR_P��� */nPkSs retrieves errno, or calls a G.blic staticlong i�l int SOCK_nt APR_P��� */nP4tap�{ return is(s, 25); }
    public staticlong i�l nUL    A returneturn is(eturneturn is(eturror
     */
    public static native lE/* Import needed classor
Nt *"ksot  would fer�llic s"ksot 25);t     n is(eturriclsanativic s"ksrlset.
     *        and are populated as follows:
     * <PRE>
  3ck�o�ABOb ce<�D- APN  aonnRASK(inp   Bke`e�_Pac nato�ABOb ce<�D- APN  aonnRASK(ihrlset.
    eof"_ECONNRESET(int s)   { rc staticlongltasN  aonnR is(eturror
     */
    p No puswoeItratatic final woe�p      'U                lic static final int APRENEU_�e�t   public   */
    Cr{7 olean APR_STATUS_x onwards    made the con atichuman n $o �/Cr{�_�ABOb APtassEptlis(s, 25); }
    public staticlong i�l int SOCK_nt APR_P��� */nP4tap�{ returblic staticlong i�li{�_�A�l(lo&| N   made the con atichuman n $o �/Cr{�_�ABOb APtass Rwn ati"'e o-sEpt"|�IATUS__��,��N_�t oe	ompl
ect�Zm fihuman  * �urn a�V�Zm fihuman n �/Cr{�_� mD�{�two�p� C�v =therw�_*
 *fi�S_E OCK_nt APR_P��#� */nds  tic final i n �/Cr{�T-long i�l nUL    A returnetuPN             ock The uLL_SOCKE;b_Sblic stat  aonnRASK(ieturtOCKat t ao�.��_*
 /Crat  ao�nsO=/Cr{}eturtOCKatong�oO;b_*
 /Crat  ao� native DCt ao�.��_*�_�A�l(lo&| N   made the con atichuman n $o �/Cr{�_�ABOb APtass Rwn ati"'e o-sEpt"|�IATUS__��,��N_�t oe	ompl
ect�Zm fihuman  * �urstat;b_*
 /CC          d�LL�/ot srnei4t�Zm f7{�T-loI�h�long s�}ae=I  U7{for  nal e�pu|k1750umo�#nnDDs    F)e�pu|ke is(s, 19  o�Zm fDMASK(in5in    ft on.
   ksot  woe is(K(in5in    f       2s, int flags, long ttlbeturn is(eturror
     */
    public static native lE/* Import needed classor
N o�Zm fD�!i}:(in5in    f       2s, int flags, long ttlbeturn is(eturror
     */
    public static native lE/* Import needed classor
N o�Zm fD�!i}:(in5in    f       2s, int flags, long ttlbeturn is(eturror
     */
    public static native lE/* Import needed classor
N o�Zm;

/** return is(zrRwn ati" final int APCthe o ati" final�Et time to agsNB/UriUR@para# ARRU     �d�r�6r   iURe o-t�al boolean APR_STATUS_IS_EB3t APRENEUtlbettlb_Sblic static final int APR_POLL_SOCKE;b_Sblic static fin iURe xNl
=tSOCKE;b_S}bliia(POL{blic st/  ket_
_SOCKnt s_  {IS_EB"SUtlbettlb_Sbliopy of ty          o-t�al blOCK_nt APR_P��#e�Aic static native lE/* Import  kSbl4  f     ihuman  * �urn a�V�Zm fihuman n �/Cr{�_� mD�{�two�p� C�v =therw�_*
 *fi�S_E OCK_nt APR_P��#� */nds  tic final i n �/Cr{�T-long i�l nUL    A returnetuP�� */nPue }
  e*/
             ihuman  * �urn a�V�Zm fihnt APR_P��#� */nds  tic final i n �/uman n �/Cnt cti1,    = Aic static native lE/* Import  kSbl4  f     ihuman  * �urn a�V�Zm fihuman n �/Cr{�_� mD�{�two�p� C�v =therw�_*
 *fi�S_E OCK_nt APR_P��#� */nds  tic final i n dO_DEBUG        = 4;    /** DebugKc final i n P     L_$�t fi�S_E{�_� mD�{�t_ =therw�_*
 *k� * L=
tse apr_so���ic native int netosErrorWV�Zm fihnt APR_P��#� */nds  tn  = tnetosErrorWV�Zm fihnt APR_Pn  = tnetosErro Cz_Sbe=fnaTe se	ompl
ect�Zmse is distrigect�Zm se	ompl
ect�Zmse is distrigect�Zm se	ompl
ejlno lo Dl int APR_POLLERR  =D�o lo Dl intIde the coAs  tn  = tnetosErrorXno Dl intIde the coAs  tn  = tf3��Apet I intIde the che coAs  tn7Dl int AP�l nUL    A retur/UriUR@p�o lo D��t I intIde(}iUR@pf3��AsN* ImportkSbl4  f  3UntIde(}iUR@pf3��APn * Deb_�A�l(lo&| N   made the con aticb Debclongg i�N:RsN* ImportkSbl4  f  3UntIde(}iUR@pf3��APn * Deb_�A�l(lo&| N   made the con aticb Debclongg i�N:RsN* ImportkSbl4  f  3UntIde(}iUR@pf3��APn * Deb_�A�l(lo&| N   made the con aticb Debclongg i�N:RsN* ImportkSbl4  f  3UntIde(}iUR@pf3��APn * Deb_�A�l(lo&| N   made,tim�-cb Debclongg i�N:RsN* ImportkSbl4H{W */nP4ted toUntI(APR_OS_START_STATUS +�pe this f�iiead would fail.)
     */
    c static final boolean Aas us   ARRU                would fail.)
     */
    c static final boolean Aas us   ARRU                would fail.)
     */
    c static final boolean Aas us   ARRU ot, long �t* Rl4H{W */nP4ted toUntI(Areturneturn G�ErrorXn�iGatic finmportkSbic fisG�Errort�iGatrn a�V 3Uead woulatic pt�k�tic finmportkong pollset, lan Aas us   ARRG�Errort�iGatrn a�V 3UeadmportkSbic fisG�Errort popn a�V 3UeadmportkSbic fisG i�Ny$#nnDDs    F)e�pu|keJNn�/ot Lc fi�     #ntportkSbic fisG�Errort�iG�a.m pollsmv  �/*bSmaon 2Y/^CONNab_       c staP6ntporturn values
     */
    /** Cannt APR_P�no Dl intId�       ��bse	om apr_so���ic native int netosErrd�r�t�ould oundatioerw5 */nds  tic final i n �/Cr
  OCKET/nP4ted toUP�n)final i n dO_DEBUG        4ted tOCKtIb final bG.blic staticlong i�l��_*��_}S  = tnetosErro Cz_Sbe=fnaTe se	ompltl intIdAa/kcon aticic f/ot c popn aporturn values
     */
    /** Cannt APR_P�no Dl intId�Xn�iGatic finmporltasN  aonnR is(eturror
     *        c final int APR_PROTO_SCTP his feature is onlIiltl intIdAa/kcon aticic f/ot c popn annt Ade(}i�d�ieasErrd�r�t�ould oundatp ntpoEB3t APRENEUtlbettlb_Se cheor
 �ic nat       public staticublic staticublic staticublic (}iUR@rs ao�V 32^nat Sr
 �i/ot 1.ErrorXno Dlss ao�/_ST
     */
    public static nati  * �ur 9_Timeout c popn a��tot Lc fi�     #ntportkSbic f    'U      */
    c static final botot Lc pse
 *        =mmm poEtaticn=ftkSbic f    'U   ould fail.)
     */
    c static ,�h  oc f i'al i ketDl intIde theodi>t�Zmse is dis�an A  public ssbiccn the operation status
     */
    sfinaive boolean� 54iR_P�n        option.
   ksot  woe�p g l       n        option.
   ksot  woe�p g l       n  option.
   ksot  woe�( lonetfa bfS%STATUS*  Senmorsmcn the operation status
     */
   p g l     fai ksot  woe�( lonetfa bfS%STaram iPR_K�  lonetfa bfS%Sf
   ksotSation status $o �/Cr{�_�ABOb APtSDE%m iPR_K�  lonetfa bfS%Sf
=3 pubotSaDoc  and  ssbiccn tt s)  aonnec}cSa{2Pv     9_ed yt�eAias  -ioyts likp_*
kso mDockA �ur 9_Timeout c popn a��tot Lc fi�     #ntportkSbic f    'U      */
    c static final botot Lc pse
 *        =mmm poEtaticn=ftkSbic f    'U   ould fail.)
     */
    c static ,�h  oc f i'al i ketDl intIde theodi>t�Zmse is dis�an A  public ssbiccn t �B    A returnetuP�� */n�c fi�ac final urnee0��)1�nL"  2}LIVbosb_Sb  * ReST
     */
af   he �tR�t   eOZmse iemplDatic final boolean Aas us   ARRU        iemplDatic final iccn t �B    A returnetuP�� */n�c fi�ac final urnee0��)1�nL"  2}LIVbosturnet s_Dkage the Li
af  'U   osDnet sHn nae
 *   ARRU       (    9_Timeo i s)  aonnR {%sl of  mpl�   ILsgW�eOZmf   he �_Timeo iw read or wr"T_GET_POOL =imitOmi1,  publicde
  L-�nL/Us   urnetucR/nP4ted iUR@pfVted iUR@pfVted iUR@pf  p g   */
    c static final botot LeportkSbic    c _ =wortkoUntI(APR_Od@wot   g  �> =imir c statil�   ILsgW�l�S_E OCK_nt APR_P��#� */ <code>falssockeRU       (    9_Timeo i s)  aonnPR_P�no D'n�iGatic [""aVE�*�RU     I  aonnPR_2LfVtedetors thawot   g  �> =im I  k   tn _P�no D'n�iGasIaonnP =im I  k   tn _P�no D'n�iGasIaonnP =im I  k   tn _P�no D'n�iGasIaonnP =im I�e socket to query
OZmf   or agreed to in writin sock   *�RU woe�p g l       n�lA�l(l   */
   tatunP =im I  k   tn _P�no Dln'ail.)
     */
    c static ,�h  oc f i'al ym�g shumanf i'al ym�g shumanf i'al ym�g shucall wil   inal int APR_INET6  = 2;
Itn _P�no
 *   ARRted   a� */lassor
Nt a2;
Itn _P�no
 p� s(s, 25); 1�nL"  2}LI144363l woe�p   ait Rl4H{W */nP4ted toUntI(Areturneturn G�ErrorXn�iGatic finmportkSbic fisG�Errortof poll
)v  /efail.uests */
     g  �>       i n     o� 0ted.
     * @parami'al 2fi�S_tic nativl  ARRU        iemplDatic final iccn t �B    A returnetuP�� */n�c fi�ac f20lues aic aآnom apr_  ARRUic final iccn t �B    A returnetuP�� */{ot c popn aporturn values
               a APR_TCP_NODinaͩP�no Dlnr
 �ietDl intIde theo.
  f�wt2;
Itn _P�no /efail.uests */
     g  �>           -d NIO2 
ied+o lo tn _P�no Dln'ail.)
OooleITE_WRITEsCP_rtko,)_P�no
 
     gMP_NODinaͩP�no Dlnr
 �ietni n dO6APR�ietnetug �t* Rl4Hit�!IlOI �o returnetuP�� tn _P�no o  4ted tu/WRIT-d NII �o n �/CN)a    -d NIO2 
ieretE�heodr [rWRIrturn valueool}�
Itn _P�no
 *   ARRted   a� */lassor
Nt a2;
Itn _P�no
 p� s(s, 25); 1�nL"  2oyts likp_*Y
     * Ac�heoetE�Mn _P�no
 *   ARRted   a� *ssbi6ONLYr"r
 UEkeRU  SOCK_ sta� dO6APR�ietnetug �t* Rl4HATUS_ stat{t acd�?uP�� * �ietni n dO6APfno /efail.uests *��,�"d   Aietnetug �t8[ C   c sIeodra                    int protocol, long cont)
        throws Exception;


p{t acd�?uP�� * �ietni n dO6APepoll

p{Wccn t �B    A returnetuP�� */{ot c p�u iPR_K�  lonetfa bfS%Sf
=3 pubot socket to remove
     * static final boto_Tib/e
   2}LIV at the OOB�{     }aeE** Don't 