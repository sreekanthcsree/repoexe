package com.dextris;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlobalExceptionHandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
